plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val runNumber: Int = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()

android {
    namespace = "br.com.motorista.painel"
    compileSdk = 34

    defaultConfig {
        applicationId = "br.com.motorista.painel"
        minSdk = 26
        targetSdk = 34
        versionCode = runNumber
        versionName = "0.1.$runNumber"
    }

    // Chave fixa: assim cada versão nova instala POR CIMA da anterior, sem perder dados.
    signingConfigs {
        create("fixa") {
            storeFile = file("painel.keystore")
            storePassword = "painel123"
            keyAlias = "painel"
            keyPassword = "painel123"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixa")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.webkit:webkit:1.11.0")
}
