package br.com.motorista.painel

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Grava, em arquivos de texto, como as telas de oferta aparecem para a acessibilidade. */
object Collector {
    private const val MAX_FILES = 150

    fun dir(ctx: Context): File {
        val d = ctx.getExternalFilesDir("coletas") ?: File(ctx.filesDir, "coletas")
        d.mkdirs()
        return d
    }

    fun count(ctx: Context): Int = dir(ctx).listFiles()?.size ?: 0

    fun save(ctx: Context, pkg: String, nodes: List<Node>, tag: String = "OK") {
        try {
            val name = SimpleDateFormat("yyyyMMdd-HHmmss-SSS", Locale.US).format(Date()) + "-" + pkg + "-" + tag + ".txt"
            val sb = StringBuilder()
            sb.append("pacote=").append(pkg).append('\n')
            sb.append("nos=").append(nodes.size).append('\n')
            for (n in nodes) {
                sb.append(n.depth).append('|').append(n.cls).append('|').append(n.id)
                    .append("|clk=").append(n.clickable)
                    .append("|bounds=").append(n.bounds)
                    .append("|text=").append(n.text.replace("\n", "⏎"))
                    .append("|desc=").append(n.desc.replace("\n", "⏎"))
                    .append('\n')
            }
            File(dir(ctx), name).writeText(sb.toString())
            val files = dir(ctx).listFiles()?.filter { !it.name.startsWith("000") }?.sortedBy { it.name } ?: return
            if (files.size > MAX_FILES) files.take(files.size - MAX_FILES).forEach { it.delete() }
        } catch (e: Exception) {
            // não deixa o coletor derrubar o serviço
        }
    }

    /** Anota só os NOMES dos pacotes (apps) vistos nas janelas, para eu descobrir o nome real da 99. */
    fun registrarPacote(ctx: Context, pacotes: Set<String>) {
        try {
            File(dir(ctx), "0000-pacotes-vistos.txt").writeText(pacotes.sorted().joinToString("\n"))
        } catch (e: Exception) { }
    }

    /** Diário curtinho (só números e avisos, sem nomes nem endereços) para eu entender por que uma oferta não foi calculada. */
    fun log(ctx: Context, linha: String) {
        try {
            val f = File(dir(ctx), "0001-diagnostico.txt")
            val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            var txt = (if (f.exists()) f.readText() else "") + t + " " + linha + "\n"
            if (txt.length > 40000) txt = txt.takeLast(30000)
            f.writeText(txt)
        } catch (e: Exception) { }
    }

    fun clear(ctx: Context) {
        dir(ctx).listFiles()?.forEach { it.delete() }
    }

    /** Junta tudo em um .zip (na pasta de cache) para compartilhar. */
    fun zip(ctx: Context): File? {
        val files = dir(ctx).listFiles()?.sortedBy { it.name } ?: return null
        if (files.isEmpty()) return null
        val out = File(ctx.cacheDir, "coletas.zip")
        ZipOutputStream(FileOutputStream(out)).use { zos ->
            for (f in files) {
                zos.putNextEntry(ZipEntry(f.name))
                zos.write(f.readBytes())
                zos.closeEntry()
            }
        }
        return out
    }
}
