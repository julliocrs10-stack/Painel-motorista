package br.com.motorista.painel

import android.content.Context
import org.json.JSONObject

/** Guarda as configurações que o painel (site dentro do app) manda para o lado Android. */
object Config {
    private const val PREFS = "painel"

    fun save(ctx: Context, json: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("config", json).apply()
    }

    private fun load(ctx: Context): JSONObject {
        return try {
            JSONObject(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("config", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
    }

    fun cop(ctx: Context): JSONObject = load(ctx).optJSONObject("copiloto") ?: JSONObject()
    fun vehicle(ctx: Context): JSONObject = load(ctx).optJSONObject("vehicle") ?: JSONObject()

    fun collector(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("collector", false)

    fun setCollector(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("collector", on).apply()
    }
}
