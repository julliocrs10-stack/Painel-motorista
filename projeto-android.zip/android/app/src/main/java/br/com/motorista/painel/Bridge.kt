package br.com.motorista.painel

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.webkit.JavascriptInterface
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File

/** Ponte entre o painel (JavaScript) e o Android. Disponível no painel como "AndroidBridge". */
class Bridge(private val act: MainActivity) {

    @JavascriptInterface
    fun setConfig(json: String) {
        Config.save(act, json)
    }

    private fun acessibilidadeLigada(): Boolean {
        if (CopilotoService.instance != null) return true
        val lista = Settings.Secure.getString(act.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return lista.split(':').any { it.startsWith(act.packageName + "/") && it.contains("CopilotoService") }
    }

    @JavascriptInterface
    fun status(): String {
        val o = JSONObject()
        o.put("acessibilidade", acessibilidadeLigada())
        o.put("coletor", Config.collector(act))
        o.put("coletas", Collector.count(act))
        o.put("android", android.os.Build.VERSION.RELEASE)
        o.put("aparelho", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL)
        try {
            o.put("versao", act.packageManager.getPackageInfo(act.packageName, 0).versionName)
        } catch (e: Exception) {
        }
        return o.toString()
    }

    @JavascriptInterface
    fun abrirAcessibilidade() {
        act.runOnUiThread { act.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    }

    @JavascriptInterface
    fun abrirInfoDoApp() {
        act.runOnUiThread {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + act.packageName))
            act.startActivity(i)
        }
    }

    @JavascriptInterface
    fun setColetor(ligado: Boolean) {
        Config.setCollector(act, ligado)
    }

    @JavascriptInterface
    fun testarPopup(): String {
        val s = CopilotoService.instance ?: return "sem_servico"
        s.rodarTeste()
        return "ok"
    }

    @JavascriptInterface
    fun limparColetas() {
        Collector.clear(act)
    }

    @JavascriptInterface
    fun compartilharColetas(): String {
        val z = Collector.zip(act) ?: return "vazio"
        compartilhar(z, "application/zip", "Enviar coletas")
        return "ok"
    }

    /** Exportar backup dentro do app: grava um arquivo e abre o menu de compartilhar. */
    @JavascriptInterface
    fun compartilharBackup(nome: String, json: String) {
        val f = File(act.cacheDir, nome.replace(Regex("[^A-Za-z0-9._-]"), "_"))
        f.writeText(json)
        compartilhar(f, "application/json", "Salvar backup")
    }

    private fun compartilhar(f: File, tipo: String, titulo: String) {
        act.runOnUiThread {
            val uri = FileProvider.getUriForFile(act, act.packageName + ".fileprovider", f)
            val i = Intent(Intent.ACTION_SEND)
            i.type = tipo
            i.putExtra(Intent.EXTRA_STREAM, uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            act.startActivity(Intent.createChooser(i, titulo))
        }
    }
}
