package br.com.motorista.painel

/**
 * Leitura da oferta a partir dos textos da tela (Uber e 99), feita em cima de prints reais.
 *
 * Uber:  "R$ 6,56"  ...  "4,87 (231)"  ...  "5 min (2.8 km)"  (até o passageiro)
 *                                         "5 minutos (2.0 km)" (a viagem)  ...  botão "Aceitar"
 * 99:    "R$15,75"  "R$2,48/km"  "4,90 · 129 corridas"  "3 min (1,4 km)"  "8 min (5 km)"
 *        (às vezes "2 min (405 m)")  e na lista "Solicitações": "(2 min 558 m) endereço".
 */
object Parser {
    private const val SP = "[\\s\\u00A0]"
    private val preco = Regex("^R\\$$SP*([0-9]{1,3}(?:\\.[0-9]{3})*(?:,[0-9]{1,2})?|[0-9]+(?:,[0-9]{1,2})?)$SP*$")
    // "5 min (2.8 km)", "5 minutos (2,0 km)", "2 min (405 m)"
    private val trecho1 = Regex("([0-9]+)$SP*min(?:utos?)?$SP*\\($SP*([0-9]+(?:[.,][0-9]+)?)$SP*(km|m)$SP*\\)", RegexOption.IGNORE_CASE)
    // "(2 min 558 m)", "(15 min 10,5 km)"
    private val trecho2 = Regex("\\($SP*([0-9]+)$SP*min(?:utos?)?$SP+([0-9]+(?:[.,][0-9]+)?)$SP*(km|m)$SP*\\)", RegexOption.IGNORE_CASE)
    // preço solto dentro de um texto maior, ex.: "R$12,33 ⚡1,2x" (não pega "R$2,61/km" nem extras como "R$1,10 por espera")
    private val precoSolto = Regex("R\\$$SP*([0-9]{1,3}(?:\\.[0-9]{3})*,[0-9]{2}|[0-9]+,[0-9]{2})(?!$SP*/)")
    private val extras = Regex("espera|Taxa|a mais|incl|parada|Tarifa|/km|por km", RegexOption.IGNORE_CASE)
    private val nota = Regex("^([45][.,][0-9]{1,2})(?![0-9])")

    private fun dec(s: String): Double = s.replace(",", ".").toDouble()
    private fun moneyNum(s: String): Double = s.replace(".", "").replace(",", ".").toDouble()

    private class Trecho(val pos: Int, val min: Double, val km: Double)

    fun parse(nodes: List<Node>): Offer? {
        var valorAtual: Double? = null
        var valor: Double? = null
        var notaOferta: Double? = null
        val trechos = ArrayList<Pair<Double, Double>>() // (min, km)

        for (n in nodes) {
            for (t in listOf(n.text, n.desc)) {
                if (t.isBlank()) continue
                val s = t.trim()

                if (!n.id.contains("earnings", ignoreCase = true)) {
                    val m = preco.find(s)
                    if (m != null) {
                        valorAtual = moneyNum(m.groupValues[1])
                        // um novo preço depois de já ter lido trechos = outra oferta; ignora o resto
                        if (trechos.isNotEmpty()) return montar(valor, trechos, notaOferta)
                        continue
                    }
                }

                if (valorAtual == null && trechos.isEmpty() && !n.id.contains("earnings", ignoreCase = true) && !extras.containsMatchIn(s)) {
                    val ps = precoSolto.find(s)
                    if (ps != null) valorAtual = moneyNum(ps.groupValues[1])
                }

                if (valorAtual != null && notaOferta == null && trechos.isEmpty()) {
                    val r = nota.find(s)
                    if (r != null) notaOferta = dec(r.groupValues[1])
                }

                // procura trechos na ordem em que aparecem no texto
                val achados = ArrayList<Trecho>()
                for (m in trecho1.findAll(s)) achados.add(Trecho(m.range.first, m.groupValues[1].toDouble(), paraKm(m.groupValues[2], m.groupValues[3])))
                for (m in trecho2.findAll(s)) achados.add(Trecho(m.range.first, m.groupValues[1].toDouble(), paraKm(m.groupValues[2], m.groupValues[3])))
                achados.sortBy { it.pos }
                for (a in achados) {
                    if (trechos.isEmpty()) valor = valorAtual
                    if (trechos.size < 2) trechos.add(Pair(a.min, a.km))
                }
            }
        }
        if (trechos.size < 2) {
            // plano B (99): o tempo e a distância podem vir em textos separados ("4 min" / "(916 m)").
            // Junta tudo em uma linha só e procura de novo.
            val junto = nodes.joinToString("\n") { it.text + "\n" + it.desc }
            val achados = ArrayList<Trecho>()
            for (m in trecho1.findAll(junto)) achados.add(Trecho(m.range.first, m.groupValues[1].toDouble(), paraKm(m.groupValues[2], m.groupValues[3])))
            for (m in trecho2.findAll(junto)) achados.add(Trecho(m.range.first, m.groupValues[1].toDouble(), paraKm(m.groupValues[2], m.groupValues[3])))
            achados.sortBy { it.pos }
            if (achados.size > trechos.size) {
                trechos.clear()
                for (a in achados) if (trechos.size < 2) trechos.add(Pair(a.min, a.km))
            }
            if (valor == null) valor = valorAtual
        }
        return montar(valor, trechos, notaOferta)
    }

    private fun paraKm(v: String, unidade: String): Double {
        val x = dec(v)
        return if (unidade.equals("m", ignoreCase = true)) x / 1000.0 else x
    }

    private fun montar(valor: Double?, trechos: List<Pair<Double, Double>>, nota: Double?): Offer? {
        if (valor == null || valor <= 0 || trechos.isEmpty()) return null
        if (trechos.size == 1) {
            // só um trecho visível: usa como a viagem toda (sem a distância até o passageiro)
            val t = trechos[0]
            if (t.second <= 0 || t.first <= 0) return null
            return Offer(valor, t.second, t.first, null, nota)
        }
        val busca = trechos[0]
        val viagem = trechos[1]
        val km = busca.second + viagem.second
        val min = busca.first + viagem.first
        if (km <= 0 || min <= 0) return null
        return Offer(valor, km, min, busca.second, nota)
    }
}
