package br.com.motorista.painel

/**
 * Leitura EXPERIMENTAL da oferta a partir dos textos da tela.
 * Procura: um valor "R$ xx,xx", distâncias "x,x km", tempos "x min" e um botão "Aceitar".
 * Será refinada com as telas reais gravadas pelo Coletor.
 */
object Parser {
    private val money = Regex("""R\$\s*([0-9]{1,3}(?:\.[0-9]{3})*(?:,[0-9]{1,2})?|[0-9]+(?:,[0-9]{1,2})?)""")
    private val km = Regex("""([0-9]+(?:[.,][0-9]+)?)\s*km""", RegexOption.IGNORE_CASE)
    private val mins = Regex("""([0-9]+)\s*min""", RegexOption.IGNORE_CASE)

    private fun moneyNum(s: String): Double = s.replace(".", "").replace(",", ".").toDouble()
    private fun kmNum(s: String): Double = s.replace(",", ".").toDouble()

    fun parse(nodes: List<Node>): Offer? {
        val all = nodes.flatMap { listOf(it.text, it.desc) }.filter { it.isNotBlank() }.distinct()

        val temBotao = all.any { it.contains("aceitar", ignoreCase = true) || it.contains("selecionar", ignoreCase = true) }
        if (!temBotao) return null

        var valor: Double? = null
        for (t in all) {
            val m = money.find(t)
            if (m != null) { valor = moneyNum(m.groupValues[1]); break }
        }
        if (valor == null) return null

        val kms = ArrayList<Double>()
        val tempos = ArrayList<Double>()
        for (t in all) {
            km.findAll(t).forEach { kms.add(kmNum(it.groupValues[1])) }
            mins.findAll(t).forEach { tempos.add(it.groupValues[1].toDouble()) }
        }
        if (kms.isEmpty() || tempos.isEmpty()) return null

        // Normalmente: 1ª distância/tempo = até o passageiro, 2ª = a viagem.
        val kmTotal = if (kms.size >= 2) kms[0] + kms[1] else kms[0]
        val minTotal = if (tempos.size >= 2) tempos[0] + tempos[1] else tempos[0]
        val busca = if (kms.size >= 2) kms[0] else null
        return Offer(valor, kmTotal, minTotal, busca, null)
    }
}
