package br.com.motorista.painel

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject

/** Desenha o pop-up por cima de outros apps, conforme as opções da aba Copiloto. */
object Popup {
    private val handler = Handler(Looper.getMainLooper())
    private var current: View? = null
    private var hideRunnable: Runnable? = null

    private fun parse(hex: String?, fallback: Int): Int {
        return try { Color.parseColor(hex) } catch (e: Exception) { fallback }
    }

    private fun shade(c: Int, p: Float): Int =
        Color.rgb((Color.red(c) * (1 - p)).toInt(), (Color.green(c) * (1 - p)).toInt(), (Color.blue(c) * (1 - p)).toInt())

    fun hide(ctx: Context) {
        handler.post { hideNow(ctx) }
    }

    private fun hideNow(ctx: Context) {
        hideRunnable?.let { handler.removeCallbacks(it) }
        hideRunnable = null
        val v = current
        if (v != null) {
            try {
                val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                wm.removeView(v)
            } catch (e: Exception) {
            }
        }
        current = null
    }

    fun show(ctx: Context, cop: JSONObject, r: Result) {
        handler.post {
            try {
                hideNow(ctx)
                val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val d = ctx.resources.displayMetrics
                val widthPct = when (cop.optString("tamanho", "m")) { "p" -> 0.62f; "g" -> 0.96f; else -> 0.80f }
                val pos = cop.optJSONObject("pos")
                val px = pos?.optInt("x", 1) ?: 1
                val py = pos?.optInt("y", 0) ?: 0

                val view = build(ctx, cop, r)
                val lp = WindowManager.LayoutParams(
                    (d.widthPixels * widthPct).toInt(),
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT
                )
                val gx = when (px) { 0 -> Gravity.START; 2 -> Gravity.END; else -> Gravity.CENTER_HORIZONTAL }
                val gy = when (py) { 0 -> Gravity.TOP; 2 -> Gravity.BOTTOM; else -> Gravity.CENTER_VERTICAL }
                lp.gravity = gx or gy
                lp.x = (8 * d.density).toInt()
                lp.y = when (py) { 0 -> (56 * d.density).toInt(); 2 -> (28 * d.density).toInt(); else -> 0 }

                view.setOnClickListener { hideNow(ctx) }
                wm.addView(view, lp)
                current = view

                val seg = cop.optInt("popupSeg", 8).coerceIn(2, 60)
                val run = Runnable { hideNow(ctx) }
                hideRunnable = run
                handler.postDelayed(run, seg * 1000L)
            } catch (e: Exception) {
                // sem permissão/serviço: ignora
            }
        }
    }

    private fun build(ctx: Context, cop: JSONObject, r: Result): View {
        val density = ctx.resources.displayMetrics.density
        val s = when (cop.optString("tamanho", "m")) { "p" -> 0.85f; "g" -> 1.2f; else -> 1.0f }
        fun dp(v: Float): Int = (v * density * s).toInt()

        val cores = cop.optJSONObject("cores")
        val padrao = when (r.nivel) { "verde" -> 0xFF4FD1A5.toInt(); "amarelo" -> 0xFFF2A93B.toInt(); else -> 0xFFE8615A.toInt() }
        val cor = parse(cores?.optString(r.nivel), padrao)
        val op = cop.optInt("opac", 92).coerceIn(50, 100) * 255 / 100

        val bgColor: Int
        val fg: Int
        val titleCol: Int
        val subCol: Int
        val boxBg: Int
        val stroke: Int
        when (cop.optString("fundo", "escuro")) {
            "claro" -> {
                bgColor = Color.argb(op, 255, 255, 255); fg = Color.parseColor("#1A1F29")
                titleCol = shade(cor, 0.35f); subCol = Color.parseColor("#5B6577")
                boxBg = Color.argb(15, 0, 0, 0); stroke = cor
            }
            "cor" -> {
                bgColor = Color.argb(op, Color.red(cor), Color.green(cor), Color.blue(cor)); fg = Color.parseColor("#0B1410")
                titleCol = fg; subCol = Color.argb(180, 11, 20, 16)
                boxBg = Color.argb(97, 255, 255, 255); stroke = shade(cor, 0.3f)
            }
            else -> {
                bgColor = Color.argb(op, 18, 22, 30); fg = Color.parseColor("#EEF2F7")
                titleCol = cor; subCol = Color.parseColor("#9AA4B5")
                boxBg = Color.argb(20, 255, 255, 255); stroke = cor
            }
        }
        val radius = when (cop.optString("formato", "suave")) { "reto" -> 4f * density; "redondo" -> 34f * density * s; else -> 20f * density * s }

        fun tv(t: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false): TextView {
            val v = TextView(ctx)
            v.text = t
            v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp * s)
            v.setTextColor(color)
            if (mono) v.typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
            else if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
            return v
        }

        val mostrar = cop.optJSONObject("mostrar")
        fun on(k: String, def: Boolean): Boolean = mostrar?.optBoolean(k, def) ?: def

        val titulo = when (r.nivel) { "verde" -> "VALE A PENA"; "amarelo" -> "NO LIMITE"; else -> "NÃO VALE" }
        val emoji = when (r.nivel) { "verde" -> "🟢"; "amarelo" -> "🟡"; else -> "🔴" }
        val base = if (cop.optString("base", "bruto") == "liquido") "líquido" else "bruto"

        val metricas = ArrayList<Pair<String, String>>()
        if (on("rsKm", true)) metricas.add("R$/km" to Evaluator.fmt2(r.rsKm))
        if (on("rsHora", true)) metricas.add("R$/hora" to Evaluator.fmt2(r.rsHora))
        if (on("lucro", true)) metricas.add("Lucro" to Evaluator.money(r.lucro))
        if (on("custo", false)) metricas.add("Custo" to Evaluator.money(r.custo))

        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(14f), dp(12f), dp(14f), dp(12f))
        val bg = GradientDrawable()
        bg.setColor(bgColor)
        bg.cornerRadius = radius
        bg.setStroke((2 * density).toInt(), stroke)
        root.background = bg

        val estilo = cop.optString("estilo", "completo")
        if (estilo == "faixa") {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            row.addView(tv(emoji, 30f, fg))
            val t = tv("  $titulo", 24f, titleCol, bold = true)
            row.addView(t)
            root.addView(row)
        } else if (estilo == "compacto") {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.addView(tv(emoji, 22f, fg))
            row.addView(tv("  $titulo", 18f, titleCol, bold = true))
            root.addView(row)
            val inl = metricas.joinToString(" · ") {
                when (it.first) { "R$/km" -> it.second + "/km"; "R$/hora" -> it.second + "/h"; else -> it.first.lowercase() + " " + it.second }
            }
            if (inl.isNotEmpty()) root.addView(tv(inl, 13f, fg, bold = true, mono = true))
            if (on("motivos", true) && r.nivel != "verde") root.addView(tv(r.motivos[0], 11f, subCol))
        } else {
            val head = LinearLayout(ctx)
            head.orientation = LinearLayout.HORIZONTAL
            head.gravity = Gravity.CENTER_VERTICAL
            head.addView(tv(emoji, 30f, fg))
            val col = LinearLayout(ctx)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(dp(10f), 0, 0, 0)
            col.addView(tv(titulo, 21f, titleCol, bold = true))
            col.addView(tv("Seus limites ($base)", 11f, subCol))
            head.addView(col)
            root.addView(head)

            var i = 0
            while (i < metricas.size) {
                val linha = LinearLayout(ctx)
                linha.orientation = LinearLayout.HORIZONTAL
                val lpTop = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lpTop.topMargin = dp(8f)
                linha.layoutParams = lpTop
                for (j in 0 until 2) {
                    val box = LinearLayout(ctx)
                    box.orientation = LinearLayout.VERTICAL
                    box.setPadding(dp(8f), dp(6f), dp(8f), dp(6f))
                    val bb = GradientDrawable()
                    bb.setColor(boxBg)
                    bb.cornerRadius = 10f * density * s
                    box.background = bb
                    val lpBox = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    lpBox.rightMargin = if (j == 0) dp(6f) else 0
                    box.layoutParams = lpBox
                    if (i + j < metricas.size) {
                        val m = metricas[i + j]
                        box.addView(tv(m.first.uppercase(), 9f, subCol))
                        box.addView(tv(m.second, 16f, fg, bold = true, mono = true))
                    } else {
                        box.background = null
                    }
                    linha.addView(box)
                }
                root.addView(linha)
                i += 2
            }
            if (on("motivos", true)) {
                val mv = tv(r.motivos.joinToString("\n") { "• $it" }, 12f, fg)
                mv.setPadding(0, dp(8f), 0, 0)
                root.addView(mv)
            }
        }
        return root
    }
}
