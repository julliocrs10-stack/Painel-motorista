package br.com.motorista.painel

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject

/** Desenha o pop-up por cima de outros apps, conforme as opções da aba Copiloto. */
object Popup {
    private val handler = Handler(Looper.getMainLooper())
    // um pop-up por lado: "L" (esquerda), "R" (direita) ou "F" (tela toda)
    private val views = HashMap<String, View>()
    private val runs = HashMap<String, Runnable>()

    private fun parse(hex: String?, fallback: Int): Int {
        return try { Color.parseColor(hex) } catch (e: Exception) { fallback }
    }

    private fun shade(c: Int, p: Float): Int =
        Color.rgb((Color.red(c) * (1 - p)).toInt(), (Color.green(c) * (1 - p)).toInt(), (Color.blue(c) * (1 - p)).toInt())

    fun hide(ctx: Context) {
        handler.post {
            for (k in ArrayList(views.keys)) hideNow(ctx, k)
        }
    }

    private fun hideNow(ctx: Context, key: String) {
        runs.remove(key)?.let { handler.removeCallbacks(it) }
        val v = views.remove(key)
        if (v != null) {
            try {
                val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                wm.removeView(v)
            } catch (e: Exception) {
            }
        }
    }

    /**
     * Mostra o pop-up em cima da janela do app que mandou a oferta.
     * Se a tela está dividida (Uber de um lado, 99 do outro), o pop-up fica só na metade daquele app.
     */
    fun show(ctx: Context, cop: JSONObject, r: Result, area: Rect? = null, app: String = "uber") {
        handler.post {
            try {
                val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val d = ctx.resources.displayMetrics
                val tela = Rect(0, 0, d.widthPixels, d.heightPixels)
                val divide = area != null && area.width() < tela.width() * 0.8f
                val reg = if (divide) Rect(area!!.left.coerceAtLeast(0), 0, area.right.coerceAtMost(tela.right), tela.bottom) else tela
                val key = app

                hideNow(ctx, key)

                // posição, largura e tamanho das letras deste app (editados na aba Copiloto)
                val pc = cop.optJSONObject("popups")?.optJSONObject(app)
                val xPct = pc?.optDouble("x", 4.0) ?: 4.0
                val yPct = pc?.optDouble("y", 3.0) ?: 3.0
                val wPct = (pc?.optDouble("w", 92.0) ?: 92.0).coerceIn(30.0, 100.0)
                val esc = (pc?.optDouble("esc", 80.0) ?: 80.0).coerceIn(50.0, 140.0)

                // em tela cheia (um app só) o pop-up fica com metade do tamanho
                val w = (reg.width() * wPct / 100.0 * (if (divide) 1.0 else 0.5)).toInt()
                val view = build(ctx, cop, r, app, (esc / 100.0).toFloat())
                val lp = WindowManager.LayoutParams(
                    w,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT
                )
                lp.gravity = Gravity.START or Gravity.TOP
                val xMax = (reg.width() - w).coerceAtLeast(0)
                lp.x = reg.left + (reg.width() * xPct / 100.0).toInt().coerceIn(0, xMax)
                lp.y = (reg.height() * yPct.coerceIn(0.0, 92.0) / 100.0).toInt()

                view.setOnClickListener { hideNow(ctx, key) }
                wm.addView(view, lp)
                views[key] = view

                val seg = cop.optInt("popupSeg", 8).coerceIn(2, 60)
                val run = Runnable { hideNow(ctx, key) }
                runs[key] = run
                handler.postDelayed(run, seg * 1000L)
            } catch (e: Exception) {
                // sem permissão/serviço: ignora
            }
        }
    }

    private fun build(ctx: Context, cop: JSONObject, r: Result, app: String, escala: Float): View {
        val density = ctx.resources.displayMetrics.density
        val s = escala
        fun dp(v: Float): Int = (v * density * s).toInt()

        val cores = cop.optJSONObject("cores")
        val padrao = when (r.nivel) { "verde" -> 0xFF4FD1A5.toInt(); "amarelo" -> 0xFFF2A93B.toInt(); else -> 0xFFE8615A.toInt() }
        val cor = parse(cores?.optString(r.nivel), padrao)
        val op = cop.optInt("opac", 92).coerceIn(50, 100) * 255 / 100

        val bgColor: Int
        val fg: Int
        val titleCol: Int
        val subCol: Int
        val boxBg: Int
        val stroke: Int
        when (cop.optString("fundo", "escuro")) {
            "claro" -> {
                bgColor = Color.argb(op, 255, 255, 255); fg = Color.parseColor("#1A1F29")
                titleCol = shade(cor, 0.35f); subCol = Color.parseColor("#5B6577")
                boxBg = Color.argb(15, 0, 0, 0); stroke = cor
            }
            "cor" -> {
                bgColor = Color.argb(op, Color.red(cor), Color.green(cor), Color.blue(cor)); fg = Color.parseColor("#0B1410")
                titleCol = fg; subCol = Color.argb(180, 11, 20, 16)
                boxBg = Color.argb(97, 255, 255, 255); stroke = shade(cor, 0.3f)
            }
            else -> {
                bgColor = Color.argb(op, 18, 22, 30); fg = Color.parseColor("#EEF2F7")
                titleCol = cor; subCol = Color.parseColor("#9AA4B5")
                boxBg = Color.argb(20, 255, 255, 255); stroke = cor
            }
        }
        val radius = when (cop.optString("formato", "suave")) { "reto" -> 4f * density; "redondo" -> 34f * density * s; else -> 20f * density * s }

        fun tv(t: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false): TextView {
            val v = TextView(ctx)
            v.text = t
            v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp * s)
            v.setTextColor(color)
            if (mono) v.typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
            else if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
            return v
        }

        val mostrar = cop.optJSONObject("mostrar")
        fun on(k: String, def: Boolean): Boolean = mostrar?.optBoolean(k, def) ?: def

        val fundoModo = cop.optString("fundo", "escuro")
        fun corNivel(n: String): Int {
            val padraoN = when (n) { "verde" -> 0xFF4FD1A5.toInt(); "amarelo" -> 0xFFF2A93B.toInt(); else -> 0xFFE8615A.toInt() }
            return parse(cores?.optString(n), padraoN)
        }
        // cor do texto de um número: pintado pelo nível; no fundo claro escurece um pouco; no fundo colorido usa a cor do texto
        fun corNum(n: String): Int = when (fundoModo) { "cor" -> fg; "claro" -> shade(corNivel(n), 0.35f); else -> corNivel(n) }
        fun nivelDe(v: Double, verde: Double, amarelo: Double): String = if (v >= verde) "verde" else if (v >= amarelo) "amarelo" else "vermelho"
        val nK = nivelDe(r.vKm, cop.optDouble("kmVerde", 2.0), cop.optDouble("kmAmarelo", 1.6))
        val nH = nivelDe(r.vH, cop.optDouble("horaVerde", 40.0), cop.optDouble("horaAmarelo", 32.0))

        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(14f), dp(11f), dp(14f), dp(11f))
        val bg = GradientDrawable()
        bg.setColor(bgColor)
        bg.cornerRadius = radius
        val bordaNeutra = if (fundoModo == "claro") Color.argb(40, 0, 0, 0) else Color.argb(46, 255, 255, 255)
        bg.setStroke((1.2f * density).toInt().coerceAtLeast(1), bordaNeutra)
        root.background = bg

        val mostraTag = cop.optJSONObject("popups")?.optJSONObject(app)?.optBoolean("tag", true) ?: true
        val tagTxt = if (app == "n99") "99" else "UBER"
        fun tagView(): TextView {
            val t = tv(tagTxt, 10f, fg, bold = true)
            t.setPadding(dp(8f), dp(2f), dp(8f), dp(2f))
            val g = GradientDrawable(); g.setColor(boxBg); g.cornerRadius = 99f * density
            t.background = g
            return t
        }
        // UMA bolinha só: a cor geral da corrida (boa / no limite / ruim)
        fun bolinha(tam: Float): View {
            val v = View(ctx)
            val g = GradientDrawable(); g.shape = GradientDrawable.OVAL; g.setColor(cor)
            v.background = g
            v.layoutParams = LinearLayout.LayoutParams(dp(tam), dp(tam))
            return v
        }
        fun espaco(): View {
            val v = View(ctx)
            v.layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
            return v
        }
        fun linhaTopo(tamBolinha: Float): LinearLayout {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            if (mostraTag) row.addView(tagView())
            row.addView(espaco())
            row.addView(bolinha(tamBolinha))
            return row
        }
        fun numero(valor: String, sufixo: String, rotulo: String, nivelCor: String, tamSp: Float): LinearLayout {
            val col = LinearLayout(ctx)
            col.orientation = LinearLayout.VERTICAL
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            col.layoutParams = lp
            val linha = LinearLayout(ctx)
            linha.orientation = LinearLayout.HORIZONTAL
            linha.gravity = Gravity.BOTTOM
            linha.addView(tv(valor, tamSp, corNum(nivelCor), bold = true))
            if (sufixo.isNotEmpty()) {
                val sf = tv(sufixo, tamSp * 0.42f, subCol)
                sf.setPadding(dp(3f), 0, 0, dp(3f))
                linha.addView(sf)
            }
            col.addView(linha)
            if (rotulo.isNotEmpty()) col.addView(tv(rotulo.uppercase(), 9f, subCol))
            return col
        }

        val estilo = cop.optString("estilo", "completo")
        val temKm = on("rsKm", true)
        val temHora = on("rsHora", true)
        if (estilo == "faixa") {
            // só a cor: o app e a bolinha
            val row = linhaTopo(18f)
            root.addView(row)
        } else if (estilo == "compacto") {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            if (mostraTag) {
                val t = tagView()
                val l = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                l.rightMargin = dp(8f)
                t.layoutParams = l
                row.addView(t)
            }
            if (temKm) row.addView(numero(Evaluator.fmt2(r.rsKm), "/km", "", nK, 20f))
            if (temHora) row.addView(numero(Evaluator.fmt2(r.rsHora), "/h", "", nH, 20f))
            row.addView(bolinha(14f))
            root.addView(row)
            if (on("motivos", true) && r.nivel != "verde") root.addView(tv(r.motivos[0], 11f, subCol))
        } else {
            root.addView(linhaTopo(14f))
            if (temKm || temHora) {
                val nums = LinearLayout(ctx)
                nums.orientation = LinearLayout.HORIZONTAL
                val lpN = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lpN.topMargin = dp(6f)
                nums.layoutParams = lpN
                if (temKm) nums.addView(numero(Evaluator.fmt2(r.rsKm), "", "R$ por km", nK, 28f))
                if (temHora) nums.addView(numero(Evaluator.fmt2(r.rsHora), "", "R$ por hora", nH, 28f))
                root.addView(nums)
            }
            val extras = ArrayList<String>()
            if (on("lucro", true)) extras.add("Lucro " + Evaluator.money(r.lucro))
            if (on("custo", false)) extras.add("Custo " + Evaluator.money(r.custo))
            if (extras.isNotEmpty()) {
                val ex = tv(extras.joinToString("  ·  "), 12f, subCol)
                ex.setPadding(0, dp(6f), 0, 0)
                root.addView(ex)
            }
            if (on("motivos", true) && r.nivel != "verde") {
                val mv = tv(r.motivos.joinToString("\n") { "• $it" }, 11f, fg)
                mv.setPadding(0, dp(6f), 0, 0)
                root.addView(mv)
            }
        }
        return root
    }
}
