package br.com.motorista.painel

/** Um elemento da tela lido pela acessibilidade. */
data class Node(
    val depth: Int,
    val cls: String,
    val id: String,
    val text: String,
    val desc: String,
    val bounds: String,
    val clickable: Boolean
)

/** Dados de uma oferta de corrida. */
data class Offer(
    val valor: Double,
    val km: Double,
    val min: Double,
    val buscaKm: Double? = null,
    val nota: Double? = null
)

/** Resultado da avaliação (mesmas regras do simulador do painel). */
data class Result(
    val nivel: String,
    val rsKm: Double,
    val rsHora: Double,
    val lucro: Double,
    val custo: Double,
    val vKm: Double,
    val vH: Double,
    val motivos: List<String>
)
