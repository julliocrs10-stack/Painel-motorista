package br.com.motorista.painel

import org.json.JSONObject
import java.util.Locale

/** Mesma regra do "avaliarOferta" do painel (index.html). */
object Evaluator {
    fun fmt2(v: Double): String = String.format(Locale("pt", "BR"), "%,.2f", v)
    fun money(v: Double): String = "R$ " + fmt2(v)

    fun custoPorKm(cop: JSONObject, veh: JSONObject): Double {
        val consumo = veh.optDouble("consumoPadrao", 0.0)
        val preco = veh.optDouble("precoPadrao", 0.0)
        val comb = if (consumo > 0 && preco > 0) preco / consumo else 0.0
        return comb + cop.optDouble("manutKm", 0.15)
    }

    fun avaliar(cop: JSONObject, veh: JSONObject, o: Offer): Result? {
        if (!(o.valor > 0 && o.km > 0 && o.min > 0)) return null

        val kmVerde = cop.optDouble("kmVerde", 2.0)
        val kmAmarelo = cop.optDouble("kmAmarelo", 1.6)
        val horaVerde = cop.optDouble("horaVerde", 40.0)
        val horaAmarelo = cop.optDouble("horaAmarelo", 32.0)
        val valorMin = cop.optDouble("valorMin", 6.0)
        val buscaMax = cop.optDouble("buscaMax", 3.0)
        val notaMin = cop.optDouble("notaMin", 4.7)
        val liquido = cop.optString("base", "bruto") == "liquido"

        val horas = o.min / 60.0
        val custo = custoPorKm(cop, veh) * o.km
        val lucro = o.valor - custo
        val rsKm = o.valor / o.km
        val rsHora = o.valor / horas
        val vKm = if (liquido) lucro / o.km else rsKm
        val vH = if (liquido) lucro / horas else rsHora
        val tag = if (liquido) "líquido" else "bruto"

        var nivel = 0 // 0 verde, 1 amarelo, 2 vermelho
        val motivos = ArrayList<String>()

        if (vKm < kmAmarelo) {
            nivel = maxOf(nivel, 2); motivos.add("R$/km $tag ${fmt2(vKm)} — abaixo do mínimo (${fmt2(kmAmarelo)})")
        } else if (vKm < kmVerde) {
            nivel = maxOf(nivel, 1); motivos.add("R$/km $tag ${fmt2(vKm)} — abaixo do ideal (${fmt2(kmVerde)})")
        }
        if (vH < horaAmarelo) {
            nivel = maxOf(nivel, 2); motivos.add("R$/hora $tag ${fmt2(vH)} — abaixo do mínimo (${fmt2(horaAmarelo)})")
        } else if (vH < horaVerde) {
            nivel = maxOf(nivel, 1); motivos.add("R$/hora $tag ${fmt2(vH)} — abaixo do ideal (${fmt2(horaVerde)})")
        }
        if (valorMin > 0 && o.valor < valorMin) {
            nivel = 2; motivos.add("Valor ${money(o.valor)} — abaixo do mínimo da corrida (${money(valorMin)})")
        }
        val busca = o.buscaKm
        if (busca != null && buscaMax > 0 && busca > buscaMax) {
            nivel = 2; motivos.add("Passageiro a ${fmt2(busca)} km — mais longe que o máximo (${fmt2(buscaMax)} km)")
        }
        val nota = o.nota
        if (nota != null && notaMin > 0 && nota < notaMin) {
            nivel = 2; motivos.add("Nota ${fmt2(nota)} — abaixo da mínima (${fmt2(notaMin)})")
        }
        if (motivos.isEmpty()) motivos.add("Tudo dentro das suas regras.")

        val nome = when (nivel) { 0 -> "verde"; 1 -> "amarelo"; else -> "vermelho" }
        return Result(nome, rsKm, rsHora, lucro, custo, vKm, vH, motivos)
    }
}
