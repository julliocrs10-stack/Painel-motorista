package br.com.motorista.painel

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Lê a tela dos apps de corrida. Faz duas coisas:
 *  1) Coletor (se ligado): grava a estrutura da tela de oferta em arquivos de texto.
 *  2) Copiloto (se ligado): tenta entender a oferta, avalia e mostra o pop-up.
 */
class CopilotoService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: CopilotoService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val leitura = Runnable { processarTela() }
    private var ultimaAssinatura = ""

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        Popup.hide(this)
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    private fun ehUber(pkg: String) = pkg.startsWith("com.ubercab") || pkg.contains("uber")
    private fun eh99(pkg: String) = pkg.contains("99") || pkg.contains("taxis99")
    private fun alvo(pkg: String) = pkg != packageName && (ehUber(pkg) || eh99(pkg))

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (!alvo(pkg)) return
        handler.removeCallbacks(leitura)
        handler.postDelayed(leitura, 350)
    }

    private fun processarTela() {
        try {
            val root = rootInActiveWindow ?: return
            val pkg = root.packageName?.toString() ?: return
            if (!alvo(pkg)) return

            val nos = ArrayList<Node>()
            percorrer(root, 0, nos)

            val textos = nos.joinToString("\n") { it.text + "\n" + it.desc }
            if (!textos.contains("R$")) return
            val assinatura = textos.hashCode().toString()
            if (assinatura == ultimaAssinatura) return
            ultimaAssinatura = assinatura

            if (Config.collector(this)) Collector.save(this, pkg, nos)

            val cop = Config.cop(this)
            if (!cop.optBoolean("ativo", false)) return
            val apps = cop.optJSONObject("apps")
            if (ehUber(pkg) && !(apps?.optBoolean("uber", true) ?: true)) return
            if (eh99(pkg) && !ehUber(pkg) && !(apps?.optBoolean("n99", true) ?: true)) return

            val oferta = Parser.parse(nos) ?: return
            val r = Evaluator.avaliar(cop, Config.vehicle(this), oferta) ?: return
            Popup.show(this, cop, r)
        } catch (e: Exception) {
            // nunca derruba o serviço
        }
    }

    private fun percorrer(n: AccessibilityNodeInfo?, depth: Int, out: MutableList<Node>) {
        if (n == null || out.size >= 500 || depth > 40) return
        val b = Rect()
        n.getBoundsInScreen(b)
        out.add(
            Node(
                depth,
                n.className?.toString() ?: "",
                n.viewIdResourceName ?: "",
                n.text?.toString() ?: "",
                n.contentDescription?.toString() ?: "",
                "${b.left},${b.top},${b.right},${b.bottom}",
                n.isClickable
            )
        )
        for (i in 0 until n.childCount) {
            percorrer(n.getChild(i), depth + 1, out)
        }
    }

    /** Botão "Testar pop-up" do painel: mostra uma oferta de exemplo com as suas regras. */
    fun rodarTeste() {
        val cop = Config.cop(this)
        val r = Evaluator.avaliar(cop, Config.vehicle(this), Offer(22.0, 8.0, 17.0, 1.0, 4.9)) ?: return
        Popup.show(this, cop, r)
    }
}
