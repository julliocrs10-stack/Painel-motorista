package br.com.motorista.painel

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Lê a tela dos apps de corrida. Faz duas coisas:
 *  1) Coletor (se ligado): grava a estrutura da tela de oferta em arquivos de texto.
 *  2) Copiloto (se ligado): tenta entender a oferta, avalia e mostra o pop-up.
 */
class CopilotoService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: CopilotoService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var agendado = false
    private val leitura = Runnable { agendado = false; processarTela() }
    private val ultimaChave = HashMap<String, String>()
    private val ultimaHora = HashMap<String, Long>()
    private val semTextoLog = HashMap<String, Long>()
    private val resumoLog = HashMap<String, Long>()
    private val pacotesVistos = HashSet<String>()
    private var inicioRajada = 0L

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        Popup.hide(this)
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    private fun ehUber(pkg: String) = pkg.startsWith("com.ubercab") || pkg.contains("uber")
    private fun eh99(pkg: String) = pkg.contains("99") || pkg.contains("taxis99")
    private fun alvo(pkg: String) = pkg != packageName && (ehUber(pkg) || eh99(pkg))

    private fun agendar(ms: Long) {
        if (agendado) return
        agendado = true
        handler.postDelayed(leitura, ms)
    }

    // Não espera a tela "ficar quieta" (a barra animada do botão Aceitar nunca deixa): lê a cada 250 ms.
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (!alvo(pkg)) return
        agendar(250)
    }

    /** Lê TODAS as janelas na tela (ex.: Uber e 99 em tela dividida), não só a ativa. */
    private fun processarTela() {
        var viuOferta = false
        try {
            val raizes = ArrayList<AccessibilityNodeInfo>()
            try {
                for (w in windows) {
                    val r = w.root
                    if (r != null) raizes.add(r)
                }
            } catch (e: Exception) { }
            if (raizes.isEmpty()) {
                val r = rootInActiveWindow
                if (r != null) raizes.add(r)
            }
            for (root in raizes) {
                try { if (processarJanela(root)) viuOferta = true } catch (e: Exception) { }
            }
        } catch (e: Exception) {
            // nunca derruba o serviço
        }
        // enquanto houver uma oferta na tela, continua olhando por até 20 s (ofertas que carregam aos poucos)
        val agora = System.currentTimeMillis()
        if (viuOferta) {
            if (inicioRajada == 0L) inicioRajada = agora
            if (agora - inicioRajada < 20000) agendar(900)
        } else {
            inicioRajada = 0L
        }
    }

    private fun pareceOferta(textos: String): Boolean {
        return textos.contains("Aceitar") || textos.contains("Tenho interesse") ||
            textos.contains("Escolher") || textos.contains("Selecionar") ||
            Regex("[0-9]\\s*min(utos)?\\s*\\(").containsMatchIn(textos)
    }

    /** Devolve true se a janela parece ter uma oferta. */
    private fun processarJanela(root: AccessibilityNodeInfo): Boolean {
        val pkg = root.packageName?.toString() ?: return false
        if (pkg != packageName && pacotesVistos.add(pkg)) Collector.registrarPacote(this, pacotesVistos)
        if (!alvo(pkg)) return false

        val nos = ArrayList<Node>()
        percorrer(root, 0, nos)
        val agora = System.currentTimeMillis()

        val textos = nos.joinToString("\n") { it.text + "\n" + it.desc }
        if (textos.isBlank()) {
            if (agora - (semTextoLog[pkg] ?: 0L) > 30000) {
                semTextoLog[pkg] = agora
                Collector.log(this, "$pkg: janela SEM NENHUM TEXTO (${nos.size} nós) — o app pode estar bloqueando a leitura")
            }
            return false
        }
        // diagnóstico leve (só contagens, sem texto): a cada 15 s por app
        if (agora - (resumoLog[pkg] ?: 0L) > 15000) {
            resumoLog[pkg] = agora
            val comTexto = nos.count { it.text.isNotBlank() || it.desc.isNotBlank() }
            Collector.log(this, "$pkg: ${nos.size} nós, $comTexto com texto · R$=${textos.contains("R$")} · min=${textos.contains("min")} · km=${textos.contains("km")} · parece oferta=${pareceOferta(textos)}")
        }
        if (!pareceOferta(textos)) return false

        val oferta = Parser.parse(nos)
        val chave = if (oferta != null) "${oferta.valor}|${oferta.km}|${oferta.min}" else "t" + textos.hashCode()
        // mesma oferta já tratada há pouco: não repete
        if (ultimaChave[pkg] == chave && agora - (ultimaHora[pkg] ?: 0L) < 30000) return true
        ultimaChave[pkg] = chave
        ultimaHora[pkg] = agora

        if (oferta == null) {
            Collector.log(this, "$pkg: tela parece oferta mas NÃO consegui ler valor/km/min (${nos.size} nós)")
            if (Config.collector(this)) Collector.save(this, pkg, nos, "FALHA")
            return true
        }
        if (Config.collector(this)) Collector.save(this, pkg, nos, "OK")

        val cop = Config.cop(this)
        val resumo = "$pkg: oferta R$ ${oferta.valor} · ${"%.1f".format(oferta.km)} km · ${oferta.min.toInt()} min"
        if (!cop.optBoolean("ativo", false)) { Collector.log(this, "$resumo → sem pop-up (copiloto DESLIGADO)"); return true }
        val apps = cop.optJSONObject("apps")
        if (ehUber(pkg) && !(apps?.optBoolean("uber", true) ?: true)) { Collector.log(this, "$resumo → sem pop-up (Uber desligado em Apps)"); return true }
        if (eh99(pkg) && !ehUber(pkg) && !(apps?.optBoolean("n99", true) ?: true)) { Collector.log(this, "$resumo → sem pop-up (99 desligada em Apps)"); return true }

        val r = Evaluator.avaliar(cop, Config.vehicle(this), oferta)
        if (r == null) { Collector.log(this, "$resumo → sem pop-up (avaliação falhou)"); return true }
        val area = Rect()
        root.getBoundsInScreen(area)
        Popup.show(this, cop, r, area, if (ehUber(pkg)) "uber" else "n99")
        Collector.log(this, "$resumo → POP-UP ${r.nivel}")
        return true
    }

    private fun percorrer(n: AccessibilityNodeInfo?, depth: Int, out: MutableList<Node>) {
        if (n == null || out.size >= 500 || depth > 40) return
        val b = Rect()
        n.getBoundsInScreen(b)
        out.add(
            Node(
                depth,
                n.className?.toString() ?: "",
                n.viewIdResourceName ?: "",
                n.text?.toString() ?: "",
                n.contentDescription?.toString() ?: "",
                "${b.left},${b.top},${b.right},${b.bottom}",
                n.isClickable
            )
        )
        for (i in 0 until n.childCount) {
            percorrer(n.getChild(i), depth + 1, out)
        }
    }

    /** Botão "Testar pop-up" do painel: mostra uma oferta de exemplo com as suas regras. */
    fun rodarTeste() {
        val cop = Config.cop(this)
        val veh = Config.vehicle(this)
        val d = resources.displayMetrics
        val r1 = Evaluator.avaliar(cop, veh, Offer(22.0, 8.0, 17.0, 1.0, 4.9)) ?: return
        if (d.widthPixels > d.heightPixels) {
            // tablet deitado: mostra um pop-up de cada lado, como seria com Uber à esquerda e 99 à direita
            val r2 = Evaluator.avaliar(cop, veh, Offer(6.5, 5.0, 12.0, 2.8, 4.8)) ?: r1
            Popup.show(this, cop, r1, Rect(0, 0, d.widthPixels / 2, d.heightPixels), "uber")
            Popup.show(this, cop, r2, Rect(d.widthPixels / 2, 0, d.widthPixels, d.heightPixels), "n99")
        } else {
            Popup.show(this, cop, r1)
        }
    }
}
