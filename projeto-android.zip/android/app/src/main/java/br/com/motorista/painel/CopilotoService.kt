package br.com.motorista.painel

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Lê a tela dos apps de corrida. Faz duas coisas:
 *  1) Coletor (se ligado): grava a estrutura da tela de oferta em arquivos de texto.
 *  2) Copiloto (se ligado): tenta entender a oferta, avalia e mostra o pop-up.
 */
class CopilotoService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: CopilotoService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val leitura = Runnable { processarTela() }
    private var ultimaAssinatura = ""

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        Popup.hide(this)
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    private fun ehUber(pkg: String) = pkg.startsWith("com.ubercab") || pkg.contains("uber")
    private fun eh99(pkg: String) = pkg.contains("99") || pkg.contains("taxis99")
    private fun alvo(pkg: String) = pkg != packageName && (ehUber(pkg) || eh99(pkg))

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (!alvo(pkg)) return
        handler.removeCallbacks(leitura)
        handler.postDelayed(leitura, 350)
    }

    private val assinaturas = HashMap<String, String>()
    private val pacotesVistos = HashSet<String>()

    /** Lê TODAS as janelas na tela (ex.: Uber e 99 em tela dividida), não só a ativa. */
    private fun processarTela() {
        try {
            val raizes = ArrayList<AccessibilityNodeInfo>()
            try {
                for (w in windows) {
                    val r = w.root
                    if (r != null) raizes.add(r)
                }
            } catch (e: Exception) { }
            if (raizes.isEmpty()) {
                val r = rootInActiveWindow
                if (r != null) raizes.add(r)
            }
            for (root in raizes) {
                try { processarJanela(root) } catch (e: Exception) { }
            }
        } catch (e: Exception) {
            // nunca derruba o serviço
        }
    }

    private fun processarJanela(root: AccessibilityNodeInfo) {
        val pkg = root.packageName?.toString() ?: return
        if (pkg != packageName && pacotesVistos.add(pkg)) Collector.registrarPacote(this, pacotesVistos)
        if (!alvo(pkg)) return

        val nos = ArrayList<Node>()
        percorrer(root, 0, nos)

        val textos = nos.joinToString("\n") { it.text + "\n" + it.desc }
        val temOferta = textos.contains("R$") || textos.contains("Aceitar") || textos.contains("Selecionar")
        if (!temOferta) return
        val assinatura = textos.hashCode().toString()
        if (assinaturas[pkg] == assinatura) return
        assinaturas[pkg] = assinatura

        if (Config.collector(this)) Collector.save(this, pkg, nos)

        val cop = Config.cop(this)
        if (!cop.optBoolean("ativo", false)) return
        val apps = cop.optJSONObject("apps")
        if (ehUber(pkg) && !(apps?.optBoolean("uber", true) ?: true)) return
        if (eh99(pkg) && !ehUber(pkg) && !(apps?.optBoolean("n99", true) ?: true)) return

        val oferta = Parser.parse(nos) ?: return
        val r = Evaluator.avaliar(cop, Config.vehicle(this), oferta) ?: return
        Popup.show(this, cop, r)
    }

    private fun percorrer(n: AccessibilityNodeInfo?, depth: Int, out: MutableList<Node>) {
        if (n == null || out.size >= 500 || depth > 40) return
        val b = Rect()
        n.getBoundsInScreen(b)
        out.add(
            Node(
                depth,
                n.className?.toString() ?: "",
                n.viewIdResourceName ?: "",
                n.text?.toString() ?: "",
                n.contentDescription?.toString() ?: "",
                "${b.left},${b.top},${b.right},${b.bottom}",
                n.isClickable
            )
        )
        for (i in 0 until n.childCount) {
            percorrer(n.getChild(i), depth + 1, out)
        }
    }

    /** Botão "Testar pop-up" do painel: mostra uma oferta de exemplo com as suas regras. */
    fun rodarTeste() {
        val cop = Config.cop(this)
        val r = Evaluator.avaliar(cop, Config.vehicle(this), Offer(22.0, 8.0, 17.0, 1.0, 4.9)) ?: return
        Popup.show(this, cop, r)
    }
}
