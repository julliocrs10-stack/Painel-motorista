package br.com.motorista.painel

import org.json.JSONObject
import java.util.Locale

/** Mesma regra do "avaliarOferta" do painel (index.html). */
object Evaluator {
    fun fmt2(v: Double): String = String.format(Locale("pt", "BR"), "%,.2f", v)
    fun money(v: Double): String = "R$ " + fmt2(v)

    fun custoPorKm(cop: JSONObject, veh: JSONObject): Double {
        val consumo = veh.optDouble("consumoPadrao", 0.0)
        val preco = veh.optDouble("precoPadrao", 0.0)
        val comb = if (consumo > 0 && preco > 0) preco / consumo else 0.0
        return comb + cop.optDouble("manutKm", 0.15)
    }

    private class Cat(val nome: String, val cor: Int, val km: Double, val hora: Double)

    private fun cor(hex: String?, def: Int): Int = try { android.graphics.Color.parseColor(hex) } catch (ex: Exception) { def }

    /** Lê as categorias do painel; se não houver, monta as 5 padrão a partir dos limites antigos. */
    private fun categorias(cop: JSONObject): List<Cat> {
        val arr = cop.optJSONArray("categorias")
        val out = ArrayList<Cat>()
        if (arr != null && arr.length() >= 2) {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(Cat(o.optString("nome", ""), cor(o.optString("cor"), 0xFF999999.toInt()), o.optDouble("km", 0.0), o.optDouble("hora", 0.0)))
            }
        }
        if (out.size < 2) {
            out.clear()
            val kA = cop.optDouble("kmAmarelo", 1.6); val kV = cop.optDouble("kmVerde", 2.0)
            val hA = cop.optDouble("horaAmarelo", 32.0); val hV = cop.optDouble("horaVerde", 40.0)
            out.add(Cat("Péssimo", 0xFFD64545.toInt(), 0.0, 0.0))
            out.add(Cat("Ruim", 0xFFF2884B.toInt(), kA * 0.78, hA * 0.75))
            out.add(Cat("Mais ou menos", 0xFFF2C94C.toInt(), kA, hA))
            out.add(Cat("Bom", 0xFF8BD450.toInt(), kV, hV))
            out.add(Cat("Ótimo", 0xFF2FCB8F.toInt(), kV * 1.25, hV * 1.25))
        }
        out.sortWith(compareBy({ it.km }, { it.hora }))
        return out
    }

    private fun catDe(v: Double, km: Boolean, cats: List<Cat>): Int {
        var idx = 0
        for (i in cats.indices) if (v >= (if (km) cats[i].km else cats[i].hora)) idx = i
        return idx
    }

    fun avaliar(cop: JSONObject, veh: JSONObject, o: Offer): Result? {
        if (!(o.valor > 0 && o.km > 0 && o.min > 0)) return null

        val cats = categorias(cop)
        val last = cats.size - 1
        val valorMin = cop.optDouble("valorMin", 6.0)
        val buscaMax = cop.optDouble("buscaMax", 3.0)
        val notaMin = cop.optDouble("notaMin", 4.7)
        val liquido = cop.optString("base", "bruto") == "liquido"

        val horas = o.min / 60.0
        val custo = custoPorKm(cop, veh) * o.km
        val lucro = o.valor - custo
        val rsKm = o.valor / o.km
        val rsHora = o.valor / horas
        val vKm = if (liquido) lucro / o.km else rsKm
        val vH = if (liquido) lucro / horas else rsHora
        val tag = if (liquido) "líquido" else "bruto"

        val iK = catDe(vKm, true, cats)
        val iH = catDe(vH, false, cats)
        var idx = minOf(iK, iH)
        val motivos = ArrayList<String>()
        if (iK < last) motivos.add("R$/km $tag ${fmt2(vKm)} (${cats[iK].nome}) — para ${cats[iK + 1].nome} precisa de ${fmt2(cats[iK + 1].km)}")
        if (iH < last) motivos.add("R$/hora $tag ${fmt2(vH)} (${cats[iH].nome}) — para ${cats[iH + 1].nome} precisa de ${fmt2(cats[iH + 1].hora)}")

        var reprovou = false
        if (valorMin > 0 && o.valor < valorMin) {
            reprovou = true; motivos.add("Valor ${money(o.valor)} — abaixo do mínimo da corrida (${money(valorMin)})")
        }
        val busca = o.buscaKm
        if (busca != null && buscaMax > 0 && busca > buscaMax) {
            reprovou = true; motivos.add("Passageiro a ${fmt2(busca)} km — mais longe que o máximo (${fmt2(buscaMax)} km)")
        }
        val nota = o.nota
        if (nota != null && notaMin > 0 && nota < notaMin) {
            reprovou = true; motivos.add("Nota ${fmt2(nota)} — abaixo da mínima (${fmt2(notaMin)})")
        }
        if (reprovou) idx = 0
        if (motivos.isEmpty()) motivos.add("Tudo dentro das suas regras.")

        val nome = if (idx == last) "verde" else if (idx == 0) "vermelho" else "amarelo"
        return Result(nome, rsKm, rsHora, lucro, custo, vKm, vH, motivos,
            idx == last, cats[idx].nome, cats[idx].cor, cats[iK].cor, cats[iH].cor)
    }
}
